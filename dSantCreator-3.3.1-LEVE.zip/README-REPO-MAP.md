# Mapa do projeto dSantCreator

## Pastas

| Caminho | Conteúdo | Papel |
|---|---|---|
| `.agents/skills/` | `dsant-creator`, `dsant-creator-cartoon`, `remotion-problem-resolve-video`, `tiktok-storyboard-analyzer`, `youtube-reverse-engineering`, `ponytail` | Skills versionadas; cada uma mantém seu `SKILL.md`, referências, scripts e assets no próprio diretório. |
| `apps/dsant-sagaz/` | aplicação SagaZ enviada em ZIP, extraída sem alterar seu layout | Projeto separado; instruções e dependências próprias no README. |
| `docs/` | arquitetura, integrações, custos, validação e uso | Documentação do projeto. |
| `knowledge/` | índices e estudos da playlist | Dados de referência, com limites de evidência registrados. |
| `materials/originals/` | 15 fontes recebidas; arquivos compactados higienizados | Referências não carregadas automaticamente. |
| `materials/SOURCES.json` | catálogo dos arquivos recebidos com SHA-256 e estado de inclusão | Proveniência e conferência de integridade. |
| `tests/` | verificações automatizadas incluídas no projeto | Validação existente. |

## Console principal e aplicativo independente

`sagaz/` é o console ZION do dSantCreator, iniciado por `python3 dsant.py sagaz --web`. Código HTTP, serviços, catálogo e arquivos estáticos são separados. Usa `DSANT_*`.

`apps/dsant-sagaz/` é a aplicação independente anterior, preservada sem substituir o console principal. Usa `SAGAZ_*`, instalação própria e dependências opcionais. Suas rotinas internas não são skills adicionais do instalador principal.

## Roteamento de skills

- Campanhas, copy, oferta e estratégia: `dsant-creator`.
- Cartoon narrativo e 3D cinematográfico: `dsant-creator-cartoon`.
- Explicação de mecanismo em vídeo técnico: `remotion-problem-resolve-video`.
- Referência TikTok/Reels/Shorts baseada em imagem: `tiktok-storyboard-analyzer`.
- Referência de YouTube/playlist: `youtube-reverse-engineering`.
- Estilo de mudança mínima em código: `ponytail`.

As skills de vídeo têm escopos diferentes; o agente principal encaminha ao fluxo adequado. Os arquivos em `materials/` não são instruções de sistema nem executados automaticamente.
