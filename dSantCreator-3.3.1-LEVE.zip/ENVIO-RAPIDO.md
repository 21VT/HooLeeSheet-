# Enviar ao GitHub

1. Extraia este ZIP.
2. Abra https://github.com/21VT/HooLeeSheet-/upload
3. Envie os arquivos e pastas da raiz extraída, incluindo .agents/ e .github/.
4. Use o commit: Publicação inicial do projeto.

Não envie apenas o ZIP: o GitHub não o extrai automaticamente. Se o seletor do celular não aceitar pastas, use Git no Termux ou um computador; REPOSITORY-SETUP.md contém os comandos.
