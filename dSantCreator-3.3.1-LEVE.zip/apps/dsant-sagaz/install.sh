#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "falta python3"; exit 1; }
python3 -c 'import sys;exit(0 if sys.version_info>=(3,10) else 1)' || { echo "python 3.10+"; exit 1; }
command -v ffmpeg >/dev/null || echo "[!] ffmpeg ausente: instale para áudio e cenas"
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
mkdir -p cache memory logs
if [ -d .git ]; then
  if [ ! -e .git/hooks/pre-commit ] && [ ! -L .git/hooks/pre-commit ]; then
    ln -s ../../scripts/pre-commit .git/hooks/pre-commit
  fi
fi
chmod +x sagaz.sh scripts/pre-commit
printf '%s\n' "ok. edite .env e rode ./sagaz.sh --web"
