"""Serviço HTTP."""
