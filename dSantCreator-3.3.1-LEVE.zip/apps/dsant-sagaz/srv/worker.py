"""Fila local opcional. Jobs pendentes não sobrevivem a restart."""
import json
import os
from pathlib import Path
import queue
import re
import threading
import uuid
from tools.yt_ingest import cache_dir, video_id
Q = queue.Queue(maxsize=32)
_START = threading.Lock()
_STARTED = False

def _out():
    path = Path(os.environ.get("SAGAZ_JOBS", str(cache_dir() / "jobs")))
    path.mkdir(parents=True, exist_ok=True)
    return path

def _write(job, payload):
    path = _out() / f"{job}.json"
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    temp.replace(path)

def submit(url):
    video_id(url)
    start()
    job = uuid.uuid4().hex
    _write(job, {"state": "fila"})
    try:
        Q.put_nowait((job, url))
    except queue.Full:
        _write(job, {"state": "erro", "erro": "fila cheia"})
        raise RuntimeError("fila cheia")
    return job

def status(job):
    if not re.fullmatch(r"[a-f0-9]{32}", job):
        raise ValueError("job inválido")
    path = _out() / f"{job}.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"state": "?"}

def _work():
    from tools import yt_ingest, transcribe
    while True:
        job, url = Q.get()
        try:
            _write(job, {"state": "baixando"})
            meta = yt_ingest.ingest(url)
            _write(job, {"state": "transcrevendo"})
            audio = yt_ingest.audio_path(meta["id"])
            text = meta.get("transcript") or transcribe.to_text(transcribe.transcribe(audio))
            _write(job, {"state": "ok", "meta": meta, "text": text})
        except Exception as exc:
            _write(job, {"state": "erro", "erro": type(exc).__name__})
        finally:
            Q.task_done()

def start(n=2):
    global _STARTED
    with _START:
        if not _STARTED:
            for _ in range(n):
                threading.Thread(target=_work, daemon=True).start()
            _STARTED = True
