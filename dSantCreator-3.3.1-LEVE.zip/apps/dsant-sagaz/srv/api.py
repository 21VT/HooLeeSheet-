import hmac
import json
import os
import time
import uuid
from typing import Literal
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from agent import Agent
from core.client import Client
app = FastAPI(title="dSant SagaZ")
# Cliente compartilha somente controles de ritmo; nenhuma conversa ou memória.
CLIENT = Client()

def authorize(authorization: str | None = Header(None)):
    token = os.environ.get("SAGAZ_TOKEN", "")
    if not token:
        raise HTTPException(503, "configure SAGAZ_TOKEN")
    if not hmac.compare_digest((authorization or "").encode(), f"Bearer {token}".encode()):
        raise HTTPException(401, "token inválido")

class M(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=70000)

class R(BaseModel):
    model: Literal["dsant-sagaz"] = "dsant-sagaz"
    messages: list[M] = Field(min_length=1, max_length=100)
    stream: bool = True

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/v1/models", dependencies=[Depends(authorize)])
def models():
    return {"object": "list", "data": [{"id": "dsant-sagaz", "object": "model"}]}

@app.post("/v1/chat/completions", dependencies=[Depends(authorize)])
def chat(request: R):
    messages = [{"role": m.role, "content": m.content} for m in request.messages]
    if messages[-1]["role"] != "user" or sum(len(m["content"]) for m in messages) > 100000:
        raise HTTPException(400, "termine com user e limite o total a 100 mil caracteres")
    if messages[0]["role"] != "user" or any(a["role"] == b["role"] for a,b in zip(messages,messages[1:])):
        raise HTTPException(400, "mensagens devem alternar user e assistant")
    agent = Agent(False, persistent=False, client=CLIENT)
    user, history = messages[-1]["content"], messages[:-1]
    cid, created = "chatcmpl-" + uuid.uuid4().hex[:12], int(time.time())
    common = {"id": cid, "created": created, "model": request.model}
    if not request.stream:
        try:
            text = agent.turn(user, history=history)
        except Exception:
            raise HTTPException(502, "falha no provedor; confira configuração e disponibilidade")
        return dict(common, object="chat.completion", choices=[{"index": 0,
            "message": {"role": "assistant", "content": text}, "finish_reason": "stop"}])
    def generate():
        def event(delta, finish=None):
            return "data: " + json.dumps(dict(common, object="chat.completion.chunk",
                choices=[{"index": 0, "delta": delta, "finish_reason": finish}]), ensure_ascii=False) + "\n\n"
        try:
            yield event({"role": "assistant"})
            for chunk in agent.stream_turn(user, history=history):
                yield event({"content": chunk})
            yield event({}, "stop")
            yield "data: [DONE]\n\n"
        except Exception:
            yield "data: " + json.dumps({"error": {"message": "stream interrompido; confira o provedor", "type": "upstream_error"}}) + "\n\n"
    return StreamingResponse(generate(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
