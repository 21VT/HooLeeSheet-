# Formato de skill
Front matter YAML: name, trigger (lista), tools (lista), budget.
Corpo: Escopo, Objetivo, Passos, Schema de saída, Critério de sucesso, Nunca.
Skill de nicho exige scope: hot. Genéricas usam scope: generic ou shared.
Cada skill precisa de pelo menos três casos em evals/cases para entrar no índice.
Corpo é limitado a 4.000 caracteres. O gate offline verifica essa cobertura.
