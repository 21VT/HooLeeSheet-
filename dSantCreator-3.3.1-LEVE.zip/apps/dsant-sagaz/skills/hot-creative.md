---
name: hot-creative
trigger: ["criativo", "criativos", "anuncio hot", "camuflado"]
tools: []
budget: 900s
scope: hot
---

## Escopo
Somente contexto explicitamente adulto/hot.

## Objetivo
Criativo curto, adulto não explícito, com proposta transparente.

## Passos
1. Definir cena, público adulto e intenção permitida.
2. Escrever 0–2 / 2–6 / 6–10 / 10–12 segundos.
3. Usar legenda legível e próximo passo claro.
4. Entregar três variações por ângulo.
5. Checar atenção, curiosidade, imaginação, motivo real e direção.

## Schema de saída
cena | blocos | legenda | direcao | variacoes[] | risco_de_bloqueio | o_que_testar

## Critério de sucesso
Entrega executável, adequada ao escopo e baseada em evidência disponível.

## Nunca
Não prometer aprovação nem disfarçar oferta proibida para revisores.
