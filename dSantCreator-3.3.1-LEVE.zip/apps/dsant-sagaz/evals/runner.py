"""Gate offline por padrão; --live testa saídas e consome API. Não altera baseline."""
import argparse
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from core import router

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true", help="consome provedor configurado")
    args = parser.parse_args()
    failures = []
    total = 0
    all_skills = router.load_all(require_cases=False)
    counts = router.coverage()
    for skill in all_skills:
        if counts.get(skill["name"], 0) < 3:
            failures.append(f"{skill['name']}: menos de três casos")
    for file in sorted((ROOT / "evals/cases").glob("*.jsonl")):
        for line in file.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            case = json.loads(line)
            total += 1
            skill = router.by_name(case["skill"])
            selected = router.route(case["input"])
            if not skill or not selected or selected["name"] != case["route"]:
                failures.append(f"rota {case['input']!r}: {selected['name'] if selected else None} != {case['route']}")
                continue
            if args.live:
                from agent import Agent
                try:
                    # Não força skill: mede roteamento real e isola conversa de cada caso.
                    output = Agent(False, persistent=False).turn(case["input"]).lower()
                    good = all(t.lower() in output for t in case.get("must_contain", []))
                    good &= not any(t.lower() in output for t in case.get("must_not_contain", []))
                    if not good:
                        failures.append(f"conteúdo: {case['input']}")
                except Exception as exc:
                    failures.append(f"provedor: {type(exc).__name__}")
    if not total:
        failures.append("nenhum caso encontrado")
    for failure in failures:
        print(f"FALHA {failure}")
    print(f"{total} casos; {len(failures)} falhas; modo {'live' if args.live else 'offline'}")
    return int(bool(failures))

if __name__ == "__main__":
    raise SystemExit(main())
