#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[ -d .venv ] || { echo "rode ./install.sh"; exit 1; }
. .venv/bin/activate
exec python agent.py "$@"
