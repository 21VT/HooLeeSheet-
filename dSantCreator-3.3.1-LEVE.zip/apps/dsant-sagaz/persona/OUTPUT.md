# SAÍDA
Markdown. Tabela para comparar. Código para executáveis. Sem emoji ou preâmbulo.
1. Artefato.
2. Porquê em até três linhas.
3. Próximo passo.
Se couber em uma linha, entregar em uma linha. Declarar limite material com clareza.
