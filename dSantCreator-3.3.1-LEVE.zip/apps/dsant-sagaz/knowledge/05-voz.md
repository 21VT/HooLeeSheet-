# Clonagem de voz

Fonte indicada: https://www.youtube.com/watch?v=zGimjuSqH5E
Status: resumo fornecido pelo usuário; conteúdo original não conferido.


## Tese da fonte
Voice changer preserva a emoção da gravação. A fonte sugere amostra limpa de
50s a 2min em MP3 até 10MB, PT-BR explícito e clone instantâneo.
Esses valores são referência do resumo, não limite atual verificado.
## Execução
Usar voz própria ou autorizada. Gravar interpretação com emoção, comparar TTS e
voice changer conforme objetivo, revisar pronúncia, ruído e sincronização.
Não se passar por pessoa real sem autorização nem enganar o interlocutor sobre
quem fala. Obter consentimento antes de criar o clone.
## Custos
Os números de créditos fornecidos no briefing não foram verificados; consultar
o preço e modelo contratados antes de estimar. Não fixar custo fictício.
