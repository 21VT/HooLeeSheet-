# Camuflagem de criativo — resumo crítico

Fonte indicada: https://www.youtube.com/watch?v=YAYRxSe0Oaw
Status: resumo fornecido pelo usuário; conteúdo original não conferido.


## Tese atribuída à fonte
A fonte recomenda cenas naturais, curtas (5–15s), pouco texto e duplo sentido,
buscando parar, fazer imaginar e levar a agir. Exemplo fornecido: entrega de pizza.
## Limite de aplicação
A hipótese de que um algoritmo não compreende contexto não foi comprovada.
Não há garantia de aprovação por remover palavras, trocar legendas ou reduzir pele.
Substituir conteúdo inadequado por conteúdo permitido de fato; não esconder uma
oferta proibida de revisores. A página de destino deve corresponder à peça.
## Execução aproveitável
Uma ideia, movimento natural, narrativa curta, legenda legível e direção clara.
Comparar variantes com métricas reais. Não tratar aprovação momentânea como prova.
