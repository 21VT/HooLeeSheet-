# Minicurso — Formação NGB / BlackGhost

Fonte: https://www.youtube.com/playlist?list=PLBPobzL8BYoHZPSfnfrPR02eE5Xb4JeLi

Catálogo obtido em 04/11/2026: 16 entradas, 15 com título e legenda coletada,
1 indisponível (`kzabyAFW3r4`). A duração conhecida soma aproximadamente 259 minutos.
O total representa a lista retornada nesta consulta, não prova de catálogo completo histórico.

As 15 sínteses `.study.md` são estudos iniciais por amostragem de legendas automáticas,
com timestamps, aplicação inferida, limites e proposta de eval. Não são análise visual
nem revisão integral. Transcrições completas não fazem parte da entrega.
`manifest.json` marca `sampled`, jamais `studied`, para não mascarar a etapa pendente.

O comando `/learn URL` aprofunda cada aula usando o pipeline e provedor configurados.
Somente após concluir a análise o estado muda para `studied`. Falhas ficam por aula;
entradas indisponíveis ficam identificadas. Resultados são rascunhos, não alterações de skills.
As sínteses iniciais podem ser recuperadas como evidência externa por assunto e escopo.

## Organização
1–6: atenção, mercados, oferta, risco e disciplina operacional.
7: copy por ambiente.
8: funil Telegram e mensuração.
9: criativos.
10–15: preparação de conta, dispositivos remotos, diagnóstico e continuidade.

Leia DIVERGENCIAS.md antes de converter uma recomendação em regra.
