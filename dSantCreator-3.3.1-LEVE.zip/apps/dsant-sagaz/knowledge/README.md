# Knowledge
Doutrina destilada das fontes. Conhecimento explica o porquê; skills explicam o como.
Os cinco resumos iniciais foram fornecidos pelo usuário, não transcritos nem
verificados nesta reconstrução. São alegações das fontes, não fatos universais.
Preços, desempenho e regras de plataformas precisam de consulta atual antes de uso.
Material novo entra em `knowledge/drafts/`, com URL e evidência, e não é carregado
como instrução. Somente revisão explícita pode promovê-lo a doutrina/skill.
