# Copy para nicho hot

Fonte indicada: https://www.youtube.com/watch?v=1vDxSy3xov4
Status: resumo fornecido pelo usuário; conteúdo original não conferido.


## Definição da fonte
Copy altera o estado mental e conduz um passo. Pode ser frame, olhar ou pausa.
Cinco peças: isca → promessa → prova → tensão → direção.
Atenção por contraste, imaginação por lacuna, pertencimento e próximo passo claro.
## Quatro ambientes
| ambiente | estado | função |
|---|---|---|
| feed | entediado | parar o dedo e criar curiosidade |
| stories | curioso | construir narrativa e série |
| X1 | buscando interação | esclarecer proposta e conduzir compra consentida |
| anúncio | desconfiado | demonstrar valor sem enganar |
## Roteiro de 12 segundos
0–2 interrupção; 2–6 contexto; 6–10 interesse; 10–12 direção.
## Cinco perguntas
Para o dedo? Cria pergunta? Faz imaginar? Há motivo real para agir? Próximo passo claro?
Reescrever se não cumprir quatro. Texto de direct precisa ser refeito para anúncio.
Aplicar apenas a conteúdo adulto legal e não explícito, sem fingir intimidade pessoal.
