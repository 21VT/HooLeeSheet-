"""Registro estático; configure SAGAZ_MODEL para o modelo disponível na sua conta."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Provider:
    name: str
    base: str
    prefixes: tuple
    default_model: str

REGISTRY = {
    "nvidia": Provider("nvidia", "https://integrate.api.nvidia.com/v1", ("nvapi-",), "meta/llama-3.3-70b-instruct"),
    "deepseek": Provider("deepseek", "https://api.deepseek.com/v1", (), "deepseek-chat"),
    "openai": Provider("openai", "https://api.openai.com/v1", ("sk-proj-",), "gpt-4o"),
    "anthropic": Provider("anthropic", "https://api.anthropic.com/v1", ("sk-ant-",), "claude-sonnet-4"),
    "openrouter": Provider("openrouter", "https://openrouter.ai/api/v1", ("sk-or-",), "anthropic/claude-sonnet-4"),
    "groq": Provider("groq", "https://api.groq.com/openai/v1", ("gsk_",), "llama-3.3-70b-versatile"),
    "xai": Provider("xai", "https://api.x.ai/v1", ("xai-",), "grok-4"),
    "mistral": Provider("mistral", "https://api.mistral.ai/v1", (), "mistral-large-latest"),
    "gemini": Provider("gemini", "https://generativelanguage.googleapis.com/v1beta/openai", ("AIza",), "gemini-2.5-pro"),
    "perplexity": Provider("perplexity", "https://api.perplexity.ai", ("pplx-",), "sonar-pro"),
    "together": Provider("together", "https://api.together.xyz/v1", ("tgp_v1_",), "deepseek-ai/DeepSeek-V3"),
    "fireworks": Provider("fireworks", "https://api.fireworks.ai/inference/v1", ("fw_",), "accounts/fireworks/models/llama-v3p3-70b-instruct"),
    "cerebras": Provider("cerebras", "https://api.cerebras.ai/v1", ("csk-",), "llama-3.3-70b"),
    "deepinfra": Provider("deepinfra", "https://api.deepinfra.com/v1/openai", (), "meta-llama/Llama-3.3-70B-Instruct"),
    "hyperbolic": Provider("hyperbolic", "https://api.hyperbolic.xyz/v1", (), "meta-llama/Llama-3.3-70B-Instruct"),
    "sambanova": Provider("sambanova", "https://api.sambanova.ai/v1", (), "Meta-Llama-3.3-70B-Instruct"),
    "ollama": Provider("ollama", "http://localhost:11434/v1", (), "qwen2.5-coder:32b"),
}

def detect(key):
    for name, p in REGISTRY.items():
        if any(key.startswith(pre) for pre in p.prefixes):
            return name
    # sk- genérico é ambíguo entre provedores: não adivinhar.
    return None

def resolve(explicit, key):
    name = (explicit or detect(key) or "openai").lower()
    if name not in REGISTRY:
        raise ValueError(f"provedor desconhecido: {name}")
    return REGISTRY[name]
