import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import time
ROOT = Path(__file__).resolve().parent.parent

def _c():
    path = Path(os.environ.get("SAGAZ_DB", str(ROOT / "memory/episodes.db")))
    path.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(path, timeout=15)
    c.executescript("""CREATE TABLE IF NOT EXISTS episodes(
        id INTEGER PRIMARY KEY, ts REAL, kind TEXT, key TEXT, payload TEXT, verdict TEXT);
        CREATE VIRTUAL TABLE IF NOT EXISTS ep_fts USING fts5(body);""")
    return c

def hkey(s):
    return hashlib.sha256(s.encode()).hexdigest()[:24]

def remember(kind, key, payload, verdict="ok"):
    c = _c()
    try:
        body = json.dumps(payload, ensure_ascii=False)[:20000]
        with c:
            cur = c.execute("INSERT INTO episodes(ts,kind,key,payload,verdict) VALUES(?,?,?,?,?)",
                            (time.time(), kind, key, body, verdict))
            c.execute("INSERT INTO ep_fts(rowid,body) VALUES(?,?)", (cur.lastrowid, body))
    finally:
        c.close()

def recall(q, n=3, kind=None):
    terms = re.findall(r"\w+", q, flags=re.UNICODE)[:16]
    if not terms:
        return []
    query = " OR ".join('"' + t + '"' for t in terms)
    c = _c()
    try:
        rows = c.execute("SELECT e.payload FROM ep_fts JOIN episodes e ON e.id=ep_fts.rowid "
                         "WHERE ep_fts MATCH ? AND (? IS NULL OR e.kind = ?) ORDER BY rank LIMIT ?",
                         (query, kind, kind, n)).fetchall()
        return [r[0][:1200] for r in rows]
    finally:
        c.close()

def recent(n=10):
    c = _c()
    try:
        return c.execute("SELECT ts,kind,verdict,substr(payload,1,100) FROM episodes ORDER BY id DESC LIMIT ?", (n,)).fetchall()
    finally:
        c.close()
