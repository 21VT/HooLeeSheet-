import os
import platform
import shutil
import sys

def portrait():
    tools = {t: bool(shutil.which(t)) for t in ("git", "ffmpeg", "yt-dlp", "docker", "curl", "jq", "rg")}
    return "\n".join([f"os: {platform.system()} {platform.release()}", f"arch: {platform.machine()}",
        f"shell: {os.environ.get('SHELL', '?')}", f"python: {sys.version.split()[0]}", f"cwd: {os.getcwd()}",
        "presentes: " + (", ".join(k for k, v in tools.items() if v) or "nenhum"),
        "ausentes: " + (", ".join(k for k, v in tools.items() if not v) or "nenhum"),
        "termux: " + ("sim" if "com.termux" in os.environ.get("PREFIX", "") else "nao")])

def shell_style():
    return "powershell" if platform.system() == "Windows" else "bash"
