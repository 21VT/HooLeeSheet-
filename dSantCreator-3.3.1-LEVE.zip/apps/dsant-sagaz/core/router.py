"""Escopo explícito e pontuação por termos completos, não substrings."""
import json
import os
from pathlib import Path
import re
import unicodedata
import yaml
ROOT = Path(__file__).resolve().parent.parent

def norm(text):
    return " ".join("".join(c for c in unicodedata.normalize("NFKD", text.lower())
                             if not unicodedata.combining(c)).split())

def match(term, text):
    return re.search(r"(?<!\w)" + re.escape(norm(term)) + r"(?!\w)", text) is not None

def is_hot(text):
    low = norm(text)
    return any(match(t, low) for t in ("hot", "onlyfans", "privacy", "nicho adulto", "conteudo adulto", "modelo de of"))

def _parse(path):
    raw = path.read_text(encoding="utf-8")
    if not raw.startswith("---\n"):
        return None
    sections = raw.split("---", 2)
    if len(sections) != 3:
        raise ValueError(f"front matter inválido: {path}")
    meta = yaml.safe_load(sections[1])
    if not isinstance(meta, dict) or not isinstance(meta.get("trigger"), list) or not meta["trigger"]:
        raise ValueError(f"triggers ausentes: {path}")
    name = meta.get("name", path.stem)
    scope = meta.get("scope", "hot" if name.startswith("hot-") else "shared")
    if scope not in ("hot", "generic", "shared"):
        raise ValueError(f"escopo inválido: {path}")
    if name.startswith("hot-") and scope != "hot":
        raise ValueError(f"skill hot com escopo inválido: {path}")
    return {"name": name, "triggers": meta["trigger"], "body": sections[2].strip()[:4000],
            "path": str(path), "hot": scope == "hot", "scope": scope}

def coverage():
    counts = {}
    for path in (ROOT / "evals/cases").glob("*.jsonl"):
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                name = json.loads(line).get("skill")
                if name:
                    counts[name] = counts.get(name, 0) + 1
    return counts

def load_all(require_cases=True):
    directory = Path(os.environ.get("SAGAZ_SKILLS", str(ROOT / "skills")))
    cases = coverage() if require_cases else {}
    out = []
    for path in sorted(directory.glob("*.md")):
        if path.name.startswith("_"):
            continue
        skill = _parse(path)
        if skill and (not require_cases or cases.get(skill["name"], 0) >= 3):
            out.append(skill)
    return out

def route(text):
    low, hot = norm(text), is_hot(text)
    if match("playlist", low):
        return by_name("yt-reverse")
    candidates = []
    for skill in load_all():
        if skill["hot"] and not hot or skill["scope"] == "generic" and hot:
            continue
        score = sum(3 for trigger in skill["triggers"] if match(trigger, low))
        if score:
            candidates.append((score, skill))
    if not candidates:
        return None
    # Preferência de escopo desempata; não supera uma solicitação específica.
    return max(candidates, key=lambda x: (x[0], x[1]["hot"] if hot else x[1]["scope"] == "generic"))[1]

def by_name(name):
    return next((s for s in load_all() if s["name"] == name), None)

def index():
    return "\n".join(f"- {s['name']} [{s['scope']}]: {', '.join(s['triggers'][:6])}" for s in load_all())
