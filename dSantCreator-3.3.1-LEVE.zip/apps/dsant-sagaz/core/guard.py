"""Limite de ritmo, backoff, breaker e rotação de credenciais."""
import os
import random
import threading
import time
from dataclasses import dataclass, field

def _f(n, d):
    try:
        return max(0.0, float(os.environ.get(n, d)))
    except ValueError:
        return float(d)

@dataclass
class RateLimiter:
    min_interval: float = field(default_factory=lambda: _f("SAGAZ_MIN_INTERVAL", 1.2))
    jitter: float = field(default_factory=lambda: _f("SAGAZ_JITTER", .7))
    _last: float = 0.0
    _lock: threading.Lock = field(default_factory=threading.Lock)
    def wait(self):
        with self._lock:
            gap = self.min_interval + random.uniform(0, self.jitter)
            delay = gap - (time.monotonic() - self._last)
            if delay > 0:
                time.sleep(delay)
            self._last = time.monotonic()

@dataclass
class Backoff:
    base: float = field(default_factory=lambda: _f("SAGAZ_BACKOFF_BASE", 2))
    cap: float = field(default_factory=lambda: _f("SAGAZ_BACKOFF_CAP", 90))
    def sleep(self, attempt):
        time.sleep(random.uniform(0, min(self.cap, self.base * 2 ** attempt)))

class CircuitOpen(RuntimeError):
    pass

@dataclass
class Breaker:
    cooldown: float = field(default_factory=lambda: _f("SAGAZ_COOLDOWN", 120))
    _until: float = 0.0
    _fails: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock)
    def trip(self):
        with self._lock:
            self._fails += 1
            if self._fails >= 3:
                self._until = time.monotonic() + self.cooldown
                self._fails = 0
    def ok(self):
        with self._lock:
            self._fails = 0
    def check(self):
        if time.monotonic() < self._until:
            raise CircuitOpen("circuito temporariamente aberto; tente mais tarde")

class Rotator:
    def __init__(self, keys):
        self.keys = list(dict.fromkeys(k for k in keys if k))
        self.i = 0
        self.dead = {}
        self.lock = threading.Lock()
    def current(self):
        with self.lock:
            if not self.keys:
                return ""
            now = time.monotonic()
            for _ in self.keys:
                key = self.keys[self.i % len(self.keys)]
                if self.dead.get(key, 0) <= now:
                    return key
                self.i += 1
            raise CircuitOpen("todas as chaves estão em cooldown")
    def burn(self, key=None):
        with self.lock:
            if self.keys:
                key = key or self.keys[self.i % len(self.keys)]
                self.dead[key] = time.monotonic() + _f("SAGAZ_KEY_COOLDOWN", 900)
                self.i += 1

def sanitize(text):
    # Compatibilidade: reescrever palavras não protege contra prompt injection.
    return text.replace("\x00", "") if os.environ.get("SAGAZ_SANITIZE", "1") == "1" else text
