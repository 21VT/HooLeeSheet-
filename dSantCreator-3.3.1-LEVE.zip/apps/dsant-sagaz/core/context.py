from pathlib import Path
from . import knowledge, router
ROOT = Path(__file__).resolve().parent.parent

def system(skill=None, extra="", query=""):
    parts = [(ROOT / "persona" / f).read_text(encoding="utf-8") for f in ("POLICY.md", "SOUL.md", "OUTPUT.md")]
    hot = bool(skill and skill["hot"]) or router.is_hot(query)
    doctrine = knowledge.load(query or (skill["name"] if skill else ""), hot=hot)
    if doctrine:
        parts.append("# DOUTRINA REVISADA, NO ESCOPO\n" + doctrine)
    if skill:
        parts.append(f"# SKILL ATIVA: {skill['name']}\n{skill['body']}")
        if skill["name"] == "yt-reverse":
            parts.append((ROOT / "prompts/analyst.md").read_text(encoding="utf-8"))
    if extra:
        parts.append(extra)
    return "\n\n---\n\n".join(parts)

def compact(messages, keep=8, cap=24000):
    # Preserva o turno atual inteiro: cortar a transcrição silenciosamente perderia evidência.
    if not messages:
        return []
    tail = messages[-1:]
    size = len(tail[0].get("content", ""))
    chosen = []
    for message in reversed(messages[:-1]):
        length = len(message.get("content", ""))
        if len(chosen) >= keep or size + length > cap:
            break
        chosen.append(message)
        size += length
    out = list(reversed(chosen)) + tail
    while out and out[0]["role"] == "assistant":
        out.pop(0)
    return out
