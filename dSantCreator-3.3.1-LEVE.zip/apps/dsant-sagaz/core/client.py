import json
import os
import httpx
from . import guard, providers

class Client:
    def __init__(self):
        keys = (os.environ.get("SAGAZ_API_KEYS") or os.environ.get("SAGAZ_API_KEY") or "").split(",")
        self.rot = guard.Rotator([k.strip() for k in keys])
        self.limiter = guard.RateLimiter()
        self.backoff = guard.Backoff()
        self.breaker = guard.Breaker()
        self.provider = providers.resolve(os.environ.get("SAGAZ_PROVIDER"), self.rot.current())
        self.model = os.environ.get("SAGAZ_MODEL") or self.provider.default_model
        self.base = (os.environ.get("SAGAZ_BASE_URL") or self.provider.base).rstrip("/")

    def stream(self, messages, temperature=.7, max_tokens=8192):
        native = self.provider.name == "anthropic"
        for attempt in range(4):
            self.breaker.check()
            self.limiter.wait()
            key = self.rot.current()
            if not key and self.provider.name != "ollama" and not os.environ.get("SAGAZ_BASE_URL"):
                raise RuntimeError("configure SAGAZ_API_KEY ou um endpoint local")
            headers = {"Content-Type": "application/json"}
            payload = {"model": self.model, "messages": messages, "stream": True,
                       "temperature": temperature, "max_tokens": max_tokens}
            path = "/chat/completions"
            if native:
                headers.update({"x-api-key": key, "anthropic-version": "2023-06-01"})
                payload["system"] = "\n\n".join(m["content"] for m in messages if m["role"] == "system")
                payload["messages"] = [m for m in messages if m["role"] != "system"]
                path = "/messages"
            elif key:
                headers["Authorization"] = f"Bearer {key}"
            emitted = False
            try:
                with httpx.stream("POST", self.base + path, headers=headers, json=payload,
                                  timeout=httpx.Timeout(600, connect=30)) as response:
                    status = response.status_code
                    if status in (401, 402, 403):
                        self.rot.burn(key)
                        continue
                    if status == 429 or status >= 500:
                        if status >= 500:
                            self.breaker.trip()
                        self.backoff.sleep(attempt)
                        continue
                    if status != 200:
                        raise RuntimeError(f"provedor respondeu HTTP {status}; confira modelo e configuração")
                    terminal = False
                    for line in response.iter_lines():
                        if not line.startswith("data:"):
                            continue
                        chunk = line[5:].strip()
                        if chunk == "[DONE]":
                            terminal = True
                            break
                        try:
                            data = json.loads(chunk)
                        except json.JSONDecodeError:
                            continue
                        if data.get("error") or data.get("type") == "error":
                            raise RuntimeError("provedor interrompeu o stream")
                        if native:
                            if data.get("type") == "message_stop":
                                terminal = True
                                break
                            delta = data.get("delta", {})
                            text = delta.get("text", "") if data.get("type") == "content_block_delta" else ""
                        else:
                            choices = data.get("choices") or []
                            if not choices:
                                continue
                            if choices[0].get("finish_reason") is not None:
                                terminal = True
                            text = (choices[0].get("delta") or {}).get("content") or ""
                        if isinstance(text, str) and text:
                            emitted = True
                            yield text
                    if not terminal or not emitted:
                        raise RuntimeError("stream incompleto ou sem conteúdo; resposta não salva")
                    self.breaker.ok()
                    return
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                self.breaker.trip()
                if emitted:
                    raise RuntimeError("conexão interrompida após resposta parcial; sem repetição automática") from exc
                self.backoff.sleep(attempt)
        raise RuntimeError("tentativas esgotadas; confira credenciais, limite e modelo")
