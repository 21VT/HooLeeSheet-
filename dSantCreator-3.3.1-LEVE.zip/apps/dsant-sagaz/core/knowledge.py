"""Doutrina por escopo; rascunhos nunca entram na carga automática."""
import os
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parent.parent
HOT_DOCS = {"02-copy-hot.md", "03-camuflagem.md", "04-contingencia.md", "05-voz.md"}

def load(query, limit=2, cap=3000, hot=False):
    terms = set(re.findall(r"\w{4,}", query.lower()))
    scored = []
    directory = Path(os.environ.get("SAGAZ_KNOWLEDGE", str(ROOT / "knowledge")))
    for path in sorted(directory.glob("*.md")):
        if path.name == "README.md" or path.name in HOT_DOCS and not hot:
            continue
        body = path.read_text(encoding="utf-8")
        score = sum(t in body.lower() for t in terms)
        if score:
            scored.append((score, path.name, body))
    scored.sort(reverse=True)
    return "\n\n---\n\n".join(b[:cap] for _, _, b in scored[:limit])
