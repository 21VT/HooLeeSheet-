MARK = "dSant SagaZ / Venice Nexus"
def verify(text):
    return MARK in text

def machine_tag():
    return f"<!-- prov:{MARK} -->"

def trailer():
    return f"Generated with {MARK}"
