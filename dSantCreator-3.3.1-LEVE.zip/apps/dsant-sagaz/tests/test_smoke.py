import json
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest.mock import patch
import unittest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from core import guard, providers, router, knowledge, context, memory
from core.client import Client
from agent import Agent
from tools import yt_ingest, sponsorblock, scenes, shell
from fastapi.testclient import TestClient
from srv.api import app
import httpx

class FakeClient:
    model = 'fake-model'
    def __init__(self):
        self.requests = []
    def stream(self, messages, **kwargs):
        self.requests.append(messages)
        yield 'resposta '
        yield 'teste'

class SmokeTests(unittest.TestCase):
    def test_detect(self):
        self.assertEqual(providers.detect('nvapi-a'), 'nvidia')
        self.assertIsNone(providers.detect('zzz'))
        self.assertIsNone(providers.detect('sk-ambiguous'))

    def test_router_hot_gate(self):
        self.assertEqual(router.route('analisa esse video do youtube')['name'], 'yt-reverse')
        self.assertEqual(router.route('criativo hot pra modelo de OF')['name'], 'hot-creative')
        self.assertEqual(router.route('estrutura de oferta pra mentoria')['name'], 'offer-forge')
        self.assertEqual(router.route('copy hot com headline')['name'], 'hot-copy')
        self.assertEqual(router.route('copy headline de anúncio para oficina')['name'], 'copy-forge')

    def test_no_hot_outside_context(self):
        for query in ['modelo de anúncio para oficina', 'voz de modelo 3d', 'story e direct da oficina',
                      'bloqueio do firewall', 'criativo de anúncio genérico', 'photoshop headline', 'hotfix no sistema']:
            with self.subTest(query=query):
                self.assertFalse(router.is_hot(query))
                skill = router.route(query)
                self.assertFalse(skill and skill['hot'])

    def test_knowledge_isolation(self):
        self.assertIn('oferta', knowledge.load('estrutura de oferta').lower())
        self.assertNotIn('camuflagem', knowledge.load('camuflagem criativo').lower())
        self.assertIn('camuflagem', knowledge.load('camuflagem criativo', hot=True).lower())
        system = context.system(router.route('copy de anuncio para oficina'), query='copy de anuncio para oficina')
        self.assertNotIn('# Copy para nicho hot', system)

    def test_skills_have_triggers_and_cases(self):
        skills = router.load_all(require_cases=False)
        self.assertEqual(len(skills), 12)
        for skill in skills:
            self.assertTrue(skill['triggers'])
            self.assertGreaterEqual(router.coverage()[skill['name']], 3)
            self.assertTrue(router.by_name(skill['name']))

    def test_memory_and_query_escaping(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict('os.environ', {'SAGAZ_DB': str(Path(tmp)/'episodes.db')}):
            memory.remember('turn', 'test', {'text': 'painel automotivo'})
            self.assertTrue(memory.recall('painel? OR " automotivo!'))
            self.assertEqual(len(memory.recent()), 1)
            self.assertEqual(memory.recall('---'), [])

    def test_local_history_and_memory_scope(self):
        fake = FakeClient()
        with tempfile.TemporaryDirectory() as tmp, patch.dict('os.environ', {'SAGAZ_DB': str(Path(tmp)/'episodes.db')}):
            memory.remember('turn-hot', 'sensitive', {'u':'copy painel', 'o':'SEGREDO_HOT'})
            agent = Agent(False, client=fake)
            agent.turn('copy hot sobre painel')
            agent.turn('copy de painel para oficina')
            self.assertNotIn('SEGREDO_HOT', str(fake.requests[-1]))
            self.assertEqual(len([m for m in fake.requests[-1] if m['role'] == 'user']), 1)
            self.assertNotIn('copy hot sobre painel', str(fake.requests[-1]))

    def test_url_validation(self):
        vid = 'iOr1mbFK7G8'
        for url in [f'https://youtu.be/{vid}', f'https://www.youtube.com/watch?v={vid}',
                    f'https://youtube.com/shorts/{vid}', f'https://youtube.com/embed/{vid}']:
            self.assertEqual(yt_ingest.video_id(url), vid)
        for url in [f'https://evil.com/watch?v={vid}', f'https://youtube.com.evil.com/watch?v={vid}',
                    'https://youtube.com/watch?v=../../bad', 'file:///etc/passwd',
                    f'https://youtube.com@localhost/watch?v={vid}']:
            with self.assertRaises(ValueError):
                yt_ingest.video_id(url)

    def test_subtitles_preserve_timestamps(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            (path/'audio.pt.json3').write_text(json.dumps({'events':[{'tStartMs': 65000, 'segs':[{'utf8':'painel'}]}]}))
            self.assertEqual(yt_ingest._subs(path), '[01:05] painel')
        text = '[120:05] sponsor\n[120:20] conteudo'
        self.assertEqual(sponsorblock.strip(text, [{'start':7205, 'end':7210}]), '[120:20] conteudo')

    def test_code_is_never_executed(self):
        client = FakeClient()
        client.stream = lambda messages: iter(['```bash\ntouch SHOULD_NOT_EXIST\n```'])
        agent = Agent(True, persistent=False, client=client)
        with patch('tools.shell.run') as run:
            agent.turn('mostre um comando')
            run.assert_not_called()

    def test_history_is_not_mutated_by_build(self):
        agent = Agent(False, persistent=False, client=FakeClient())
        self.assertEqual(len(agent.build('pedido', None)), 2)
        self.assertEqual(agent.history, [])
        self.assertEqual(agent.turn('pedido'), 'resposta teste')
        self.assertEqual(len(agent.history), 2)
        self.assertEqual(agent.turn('outro'), 'resposta teste')
        self.assertEqual(len(agent.history), 4)

    def test_api_auth_and_role_boundary(self):
        with patch.dict('os.environ', {'SAGAZ_TOKEN':'test-secret'}):
            client = TestClient(app)
            payload = {'messages':[{'role':'user','content':'oi'}], 'stream':False}
            self.assertEqual(client.post('/v1/chat/completions', json=payload).status_code, 401)
            self.assertEqual(client.get('/v1/models').status_code, 401)
            headers = {'Authorization':'Bearer test-secret'}
            payload['messages'][0]['role'] = 'system'
            self.assertEqual(client.post('/v1/chat/completions', json=payload, headers=headers).status_code, 422)
        with patch.dict('os.environ', {'SAGAZ_TOKEN':''}):
            self.assertEqual(TestClient(app).get('/v1/models').status_code, 503)

    def test_api_modes_pipeline_and_history_isolation(self):
        fake = FakeClient()
        headers = {'Authorization':'Bearer test-secret'}
        with patch.dict('os.environ', {'SAGAZ_TOKEN':'test-secret'}), patch('srv.api.CLIENT', fake), \
             patch.object(Agent, 'yt_context', return_value={'meta':{'id':'iOr1mbFK7G8'}, 'text':'[00:00] exemplo'}) as ingest:
            client = TestClient(app)
            for stream in (False, True):
                payload = {'messages':[{'role':'user','content':'primeiro'}, {'role':'assistant','content':'anterior'},
                    {'role':'user','content':'analisa https://youtu.be/iOr1mbFK7G8'}], 'stream':stream}
                response = client.post('/v1/chat/completions', json=payload, headers=headers)
                self.assertEqual(response.status_code, 200)
                if stream:
                    self.assertIn('[DONE]', response.text)
                    self.assertIn('"finish_reason": "stop"', response.text)
                else:
                    self.assertEqual(response.json()['choices'][0]['message']['content'], 'resposta teste')
                self.assertEqual(fake.requests[-1][1]['content'], 'primeiro')
                self.assertIn('[00:00] exemplo', fake.requests[-1][-1]['content'])
                self.assertIn('SKILL ATIVA: yt-reverse', fake.requests[-1][0]['content'])
            self.assertEqual(ingest.call_count, 2)
            client.post('/v1/chat/completions', json={'messages':[{'role':'user','content':'pedido isolado'}], 'stream':False}, headers=headers)
            self.assertEqual(len(fake.requests[-1]), 2)
            self.assertEqual([m['content'] for m in fake.requests[-1] if m['role'] != 'system'], ['pedido isolado'])

    def test_all_keys_in_cooldown_raise(self):
        rot = guard.Rotator(['a', 'b'])
        rot.burn(rot.current())
        rot.burn(rot.current())
        with self.assertRaises(guard.CircuitOpen):
            rot.current()

    def test_provider_stream_and_native_anthropic(self):
        def exercise(provider, data):
            requests = []
            def handler(request):
                requests.append(request)
                return httpx.Response(200, text=data)
            original = httpx.stream
            def stream(*args, **kwargs):
                return httpx.Client(transport=httpx.MockTransport(handler)).stream(*args, **kwargs)
            with patch.dict('os.environ', {'SAGAZ_PROVIDER':provider, 'SAGAZ_API_KEY':'test-key',
                    'SAGAZ_API_KEYS':'', 'SAGAZ_BASE_URL':'https://test.invalid/v1',
                    'SAGAZ_MIN_INTERVAL':'0', 'SAGAZ_JITTER':'0'}), patch('core.client.httpx.stream', side_effect=stream):
                c = Client()
                result = ''.join(c.stream([{'role':'system','content':'regra'}, {'role':'user','content':'oi'}]))
            self.assertEqual(result, 'teste')
            return requests[0]
        request = exercise('openai', 'data: {"choices":[{"delta":{"content":"teste"}}]}\n\ndata: [DONE]\n\n')
        self.assertTrue(str(request.url).endswith('/chat/completions'))
        request = exercise('anthropic', 'data: {"type":"content_block_delta","delta":{"text":"teste"}}\n\ndata: {"type":"message_stop"}\n\n')
        self.assertTrue(str(request.url).endswith('/messages'))
        self.assertEqual(json.loads(request.content)['system'], 'regra')
        self.assertEqual(request.headers['x-api-key'], 'test-key')

    def test_incomplete_stream_not_retried_after_output(self):
        def stream(*args, **kwargs):
            transport = httpx.MockTransport(lambda request: httpx.Response(200,
                text='data: {"choices":[{"delta":{"content":"parcial"}}]}\n\n'))
            return httpx.Client(transport=transport).stream(*args, **kwargs)
        with patch.dict('os.environ', {'SAGAZ_PROVIDER':'ollama','SAGAZ_MIN_INTERVAL':'0', 'SAGAZ_JITTER':'0'}), \
             patch('core.client.httpx.stream', side_effect=stream) as call:
            with self.assertRaises(RuntimeError):
                list(Client().stream([{'role':'user','content':'oi'}]))
            self.assertEqual(call.call_count, 1)

    def test_learn_is_draft_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp, patch('agent.ROOT', Path(tmp)):
            agent = Agent(False, persistent=False, client=FakeClient())
            data = {'meta':{'id':'iOr1mbFK7G8', 'title':'Aula'}, 'text':'[00:00] regra fornecida'}
            with patch.object(agent, 'yt_context', return_value=data):
                path = agent.learn('https://youtu.be/iOr1mbFK7G8')
                self.assertEqual(path.parent.name, 'drafts')
                with self.assertRaises(FileExistsError):
                    agent.learn('https://youtu.be/iOr1mbFK7G8')

    def test_scene_contact_sheet_with_short_local_video(self):
        import shutil
        if not shutil.which('ffmpeg'):
            self.skipTest('ffmpeg ausente')
        with tempfile.TemporaryDirectory() as tmp, patch.dict('os.environ', {'SAGAZ_CACHE_DIR':tmp}):
            d = yt_ingest.directory('iOr1mbFK7G8')
            d.mkdir()
            video = d/'video.mp4'
            subprocess.run(['ffmpeg','-nostdin','-v','error','-f','lavfi','-i','color=c=red:s=160x90:d=1',
                            '-c:v','mpeg4','-y',str(video)], check=True, capture_output=True)
            self.assertEqual(scenes.detect('iOr1mbFK7G8'), [])
            self.assertTrue(Path(scenes.sheet('iOr1mbFK7G8', [])).is_file())
            self.assertTrue(Path(scenes.sheet('iOr1mbFK7G8', [.2, .4, .6])).is_file())

if __name__ == '__main__':
    unittest.main()
