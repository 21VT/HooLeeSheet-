import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from tools import playlist
from agent import Agent

PID='PLBPobzL8BYoHZPSfnfrPR02eE5Xb4JeLi'
URL='https://youtube.com/playlist?list='+PID
VID='TydXOf_o46Q'

def catalog(entries=None):
    return playlist.normalize({'title':'Curso', 'entries':entries or [
        {'id':VID,'title':'Aula'}, {'id':'kzabyAFW3r4','title':None}]},PID)

class PlaylistTests(unittest.TestCase):
    def test_validates_and_canonicalizes_urls(self):
        self.assertEqual(playlist.playlist_id(URL+'&si=tracking'),PID)
        self.assertTrue(playlist.is_playlist('https://youtube.com/watch?v='+VID+'&list='+PID))
        self.assertFalse(playlist.is_playlist('https://evil.com/playlist?list='+PID))
        self.assertFalse(playlist.is_playlist('https://youtube.com/playlist?list=../../bad'))
        self.assertFalse(playlist.is_playlist('https://youtube.com/watch?v='+VID))

    def test_retains_order_and_unavailable_entries(self):
        data=catalog()
        self.assertEqual([e['position'] for e in data['entries']],[1,2])
        self.assertFalse(data['entries'][1]['available'])

    def test_resumes_without_repeating_completed_study(self):
        calls=[]
        def collect(url):
            calls.append(url)
            return {'text':'[00:10] regra observada'}
        with tempfile.TemporaryDirectory() as tmp:
            path,data=playlist.run(URL,tmp,collect,lambda entry,text:'regra com fonte [00:10]',catalog=catalog())
            self.assertEqual(data['entries'][0]['state'],'studied')
            self.assertEqual(data['entries'][1]['state'],'unavailable')
            playlist.run(URL,tmp,collect,lambda entry,text:self.fail('não deve repetir'),catalog=catalog())
            self.assertEqual(len(calls),1)
            self.assertTrue((path.parent/(VID+'.full-study.md')).exists())

    def test_failure_isolated_and_retried_from_saved_transcript(self):
        def fail(entry,text):
            raise RuntimeError('provedor indisponível')
        with tempfile.TemporaryDirectory() as tmp:
            path,data=playlist.run(URL,tmp,lambda url:{'text':'[00:00] aula'},fail,catalog=catalog())
            self.assertEqual(data['entries'][0]['state'],'error')
            path,data=playlist.run(URL,tmp,lambda url:self.fail('coleta já salva'),lambda entry,text:'estudo',catalog=catalog())
            self.assertEqual(data['entries'][0]['state'],'studied')
            self.assertNotIn('error',data['entries'][0])

    def test_batch_limit_and_deduplication(self):
        cat=catalog([{'id':VID,'title':'Aula'},{'id':VID,'title':'Repetição'},
                     {'id':'zT9VvxYVT9c','title':'Outra'}])
        calls=[]
        with tempfile.TemporaryDirectory() as tmp:
            path,data=playlist.run(URL,tmp,lambda url:calls.append(url) or {'text':'aula'},
                                   lambda entry,text:'estudo',limit=1,catalog=cat)
            self.assertEqual(len(calls),1)
            self.assertEqual(data['entries'][2]['state'],'pending')
            self.assertEqual(data['entries'][1]['state'],'studied')
            playlist.run(URL,tmp,lambda url:calls.append(url) or {'text':'aula'},
                         lambda entry,text:'estudo',limit=1,catalog=cat)
            self.assertEqual(len(calls),2)
            self.assertFalse((path.parent/'.study.lock').exists())

    def test_prepare_playlist_uses_catalog_not_video_ingest(self):
        agent=Agent(False,persistent=False,client=object())
        with patch('tools.playlist.enumerate_playlist',return_value=catalog()), \
             patch.object(agent,'yt_context',side_effect=AssertionError('URL de playlist não é vídeo')):
            self.assertIn('Catálogo somente',agent.prepare('Estude '+URL))

    def test_retrieval_excludes_hot_from_generic(self):
        with tempfile.TemporaryDirectory() as tmp:
            path,data=playlist.sync(catalog(),tmp)
            data['entries'][0].update(state='sampled', scope='hot')
            playlist.write_json(path,data)
            (path.parent/(VID+'.study.md')).write_text('copy exclusiva hot com fonte')
            self.assertEqual(playlist.read_notes('copy exclusiva',tmp), '')
            self.assertIn('exclusiva',playlist.read_notes('copy exclusiva',tmp,hot=True))

    def test_learn_dispatches_playlist(self):
        agent=Agent(False,persistent=False,client=object())
        with patch.object(agent,'learn_playlist',return_value='manifest.json') as learn:
            self.assertEqual(agent.learn(URL),'manifest.json')
            learn.assert_called_once_with(URL)

if __name__=='__main__':
    unittest.main()
