# dSant SagaZ v2

Agente operacional: CLI, API compatível com chat completions e pack textual portátil.
Núcleo único; skills hot separadas das genéricas e doutrina carregada por escopo.

## Instalar — Linux / VPS

```bash
unzip dsant-sagaz.zip
cd dsant-sagaz
chmod +x install.sh sagaz.sh scripts/pre-commit
./install.sh
# Edite .env com provedor, modelo, chave e SAGAZ_TOKEN.
./sagaz.sh --web
```

O instalador cria .env somente quando ele não existe. Não copie .env.example por
cima da sua configuração. FFmpeg precisa estar no PATH. A primeira transcrição
baixa o modelo Whisper e pode consumir bastante disco/RAM; large-v3 pode ser pesado
em VPS pequena: configure SAGAZ_WHISPER_MODEL=small para começar.
Dependências não têm lockfile; estas versões mínimas vêm do briefing.

```bash
.venv/bin/python -m pytest tests/ -q
.venv/bin/python evals/runner.py
.venv/bin/python pack/build_pack.py
```

## Configuração

Configure SAGAZ_PROVIDER, SAGAZ_MODEL e SAGAZ_API_KEY. SAGAZ_API_KEYS aceita chaves
separadas por vírgula do MESMO provedor. Chaves sk- genéricas são ambíguas; configure
o provedor explicitamente. O registro é estático, não um catálogo atual validado;
confira modelo e acesso na sua conta. Anthropic usa /messages; os demais,
/chat/completions. Endpoints compatíveis próprios podem usar SAGAZ_BASE_URL.
Ollama não exige chave: configure SAGAZ_PROVIDER=ollama e SAGAZ_MODEL adequado.
Para 9Router: defina SAGAZ_BASE_URL com /v1, SAGAZ_MODEL e chave do seu endpoint.

HTTP exige SAGAZ_TOKEN. Gere um segredo local, por exemplo:

```bash
.venv/bin/python -c 'import secrets; print(secrets.token_urlsafe(32))'
```

Cole esse valor em SAGAZ_TOKEN no .env. A API escuta em 127.0.0.1 por padrão.
Use túnel SSH ou proxy HTTPS autenticado para acesso remoto. Compose publica
somente em loopback; o servidor dentro do contêiner usa 0.0.0.0.
Não embuta .env na imagem. O pacote de entrega nunca inclui .env, memória ou chaves.

## CLI

```bash
./sagaz.sh
./sagaz.sh -p "copy para reparo de painel automotivo"
```

- `/ag dSant SagaZ <pedido>`: pedido normal.
- `<URL YouTube>`: ingestão, timestamps, áudio e vídeo 480p, cenas e contact sheet.
- `/skill hot-creative <pedido>`: seleção explícita de escopo; sem pedido, mostra skill.
- `/learn <URL>`: salva transcrição em knowledge/drafts; não promove automaticamente.
- `/eval`: gate offline, sem API.
- `/pack`: gera pack/AGENT.md, já incluído no ZIP de entrega.
- `/mem`: episódios locais. A CLI grava pedidos e respostas em SQLite sem criptografia.
- `/shell <comando>`: somente se iniciou CLI com --allow-shell.

Blocos de código nunca são executados automaticamente. Shell explícito tem todos os
privilégios do usuário local e não é sandbox. SAGAZ_MAX_ITERS é mantido por compatibilidade;
esta versão não implementa loop de execução autônoma de comandos.

## API

`GET /health` não exige token; `GET /v1/models` e `POST /v1/chat/completions` exigem
Authorization: Bearer com SAGAZ_TOKEN. Corpo de exemplo:

```json
{"model":"dsant-sagaz","messages":[{"role":"user","content":"copy para minha oficina"}],"stream":false}
```

Use stream=true para SSE. Os dois modos passam pelo mesmo roteador e ingestão.
Envie histórico user/assistant alternado no próprio corpo, começando e terminando
com user. A API não usa memória global, não aceita system do cliente e não executa
shell. Cada pedido tem Agent próprio; somente rate limiter/credenciais são compartilhados.
Vídeos podem demorar antes do primeiro token de conteúdo. O worker opcional é uma
fila local de ingestão, não uma fila durável nem endpoint público. Erros de streaming
após início chegam como evento data com error e sem marcador de sucesso [DONE].

## Isolamento e regressão

Termos explícitos hot, OnlyFans, Privacy, nicho adulto, conteúdo adulto ou modelo de OF
ativam hot. Termos genéricos como modelo, criativo, anúncio, voz e story não ativam.
Copy genérica é excluída quando o escopo é hot. Skills compartilhadas continuam válidas.
Uma skill hot forçada em /skill é uma decisão explícita de contexto.
O roteamento usa apenas o pedido original; transcrições não escolhem a skill.
Doutrina hot nunca é carregada para consulta genérica. A memória local filtra por
escopo, e a CLI reinicia o histórico ativo ao alternar entre hot e genérico. Rascunhos não são indexados.
Cada skill exige três casos para entrar no índice; cobertura e rotas são testadas offline.
O gate não prova qualidade da copy. `evals/runner.py --live` consome API e aplica
checagens textuais simples; não substitui revisão humana. A baseline não muda sozinha.

## Fontes e alterações na reconstrução

config/sources.yml contém o canal e vídeos indicados. Os cinco resumos foram
fornecidos pelo usuário; os vídeos não foram conferidos nesta reconstrução.
Custos, prazos de aquecimento e hipóteses sobre bloqueios não são fatos atuais verificados.
As notas de camuflagem/contingência foram revistas para propostas transparentes,
recuperação legítima e ausência de engajamento comprado. Voz exige autorização.
A identidade foi mantida; instruções de nunca reportar falha ou ignorar autorização
foram substituídas por relato fiel e execução explícita.

## Limites do pipeline

YouTube usa yt-dlp; se legendas falham, tenta áudio e transcrição local. Download
pode falhar por login, rede ou indisponibilidade. Não há fallback por instância pública
não confiável. Limite de download por arquivo: 300 MB; duração até 2h quando conhecida.
SponsorBlock é metadado opcional: trechos são marcados, sem remover evidência do original.
A contact sheet é salva localmente; este cliente LLM é textual e recebe timestamps e
metadados, não imagens. Não alegar análise visual sem leitura multimodal real.
A passagem de material ao modelo é limitada a 70 mil caracteres; pode truncar vídeos longos.
Não há monitoramento agendado de canal nem autoedição de skills/core.

## Windows

```powershell
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
# Edite .env; FFmpeg deve estar no PATH.
.\sagaz.bat
```

Termux nativo pode exigir compilação de CTranslate2/faster-whisper; não foi validado.
Prefira VPS e acesso por SSH no celular. Docker e Windows exigem validação no seu ambiente.


## Playlist incluída — Minicurso Formação NGB

Fonte: https://www.youtube.com/playlist?list=PLBPobzL8BYoHZPSfnfrPR02eE5Xb4JeLi

Catálogo real coletado em 04/11/2026: 16 entradas, 15 com legendas disponíveis e
uma indisponível. A entrega inclui 15 sínteses iniciais por amostragem distribuída,
com timestamps, aplicações inferidas, limites e propostas de eval. Não são revisão
integral nem análise visual. As transcrições completas não são distribuídas.
Veja knowledge/playlists/PLBPobzL8BYoHZPSfnfrPR02eE5Xb4JeLi/README.md e DIVERGENCIAS.md.

O agente recupera sínteses relevantes como dados externos por escopo; notas hot não
entram em pedidos genéricos. O pack também contém essas sínteses com o escopo marcado.
URLs de playlist em pedidos normais carregam o catálogo, sem baixar todas as aulas
implicitamente no endpoint HTTP.

Para aprofundar cada aula com o provedor configurado, use na CLI:

```text
/learn https://www.youtube.com/playlist?list=PLBPobzL8BYoHZPSfnfrPR02eE5Xb4JeLi
```

Ou processe um lote de três aulas pendentes por execução:

```bash
./sagaz.sh --learn-playlist 'https://www.youtube.com/playlist?list=PLBPobzL8BYoHZPSfnfrPR02eE5Xb4JeLi' --playlist-limit 3
```

Aprofundamento usa API e pode consumir créditos do provedor e recursos de transcrição.
O progresso é salvo por aula: pending, sampled (síntese inicial), collected,
studied (análise integral pelo pipeline), error ou unavailable. A execução retoma as
pendências, não repete estudos concluídos e preserva a síntese inicial no arquivo
.study.md ao gravar aprofundamento em .full-study.md. As análises integrais continuam
rascunhos sujeitos a revisão. Novas aulas não classificadas não entram na recuperação
automática. Se o processo for morto abruptamente, remova .study.lock somente depois
de confirmar que ele terminou. Não há acompanhamento agendado da playlist.
