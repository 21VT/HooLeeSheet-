# Validação da entrega

- 26 testes pytest passaram; 7 subtestes passaram.
- 42 casos offline de cobertura/roteamento passaram.
- Python compileall e sintaxe bash passaram.
- FFmpeg testado com vídeo local: detecção e contact sheets de 1 e 4 frames.
- Provedores e API testados com transportes simulados, sem chamadas pagas.
- Dois avisos de depreciação nas dependências do ambiente de teste.
- Não validados: instalação completa de Whisper, download de áudio/vídeo YouTube, provedor real, Docker, Windows e Termux.
- Pacote contém todos os caminhos solicitados; inclui correções descritas no README.

## Playlist adicionada
- Catálogo real: 16 entradas; 15 legendas coletadas; uma entrada indisponível.
- Incluídas 15 sínteses iniciais por amostragem distribuída, com fonte e timestamps.
- As sínteses estão marcadas como sampled, sem alegar revisão integral ou análise visual.
- Testes cobrem URL, ordem, indisponibilidade, retomada, duplicatas, falhas, limite de lote,
  seleção via CLI e recuperação de notas com isolamento de escopo.
- A análise integral por API permanece pendente; não houve consumo de provedor configurado.
