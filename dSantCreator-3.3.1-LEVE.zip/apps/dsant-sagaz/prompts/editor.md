# Editor — reescrita
Cortar antes de acrescentar. Adjetivo vira número somente quando há evidência.
Uma ideia por parágrafo. Verbo na ação. Manter voz e cortar gordura.
