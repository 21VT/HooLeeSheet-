# Critic — auditoria
| gravidade | furo | correção |
Checar pedido respondido, fonte, promessa/prova, execução alegada, enchimento e escopo.
