# Pack
1. Abra conversa nova.
2. Cole AGENT.md inteiro como contexto.
3. Use /ag dSant SagaZ <comando>.
O pack é texto: não instala ferramentas nem pode garantir isolamento como o roteador
Python. Não inclui memória, .env, cache ou rascunhos. Para execução, use a CLI.
