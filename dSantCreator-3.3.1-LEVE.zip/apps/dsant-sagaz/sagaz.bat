@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo Crie .venv com py -3 -m venv .venv e instale requirements.txt & exit /b 1)
.venv\Scripts\python.exe agent.py %*
