import re
import httpx
API = "https://sponsor.ajay.app/api/skipSegments"

def segments(vid):
    try:
        r = httpx.get(API, params={"videoID": vid,
            "categories": '["sponsor","intro","outro","selfpromo","interaction"]'}, timeout=15)
        if r.status_code == 200:
            return [{"start": s["segment"][0], "end": s["segment"][1], "cat": s["category"]} for s in r.json()]
    except (httpx.HTTPError, ValueError, KeyError, TypeError, IndexError):
        pass
    return []

def strip(text, segs):
    out = []
    for line in text.splitlines():
        match = re.match(r"\[(\d+):(\d{2})\]", line)
        seconds = int(match[1]) * 60 + int(match[2]) if match else None
        if seconds is None or not any(s["start"] <= seconds < s["end"] for s in segs):
            out.append(line)
    return "\n".join(out)
