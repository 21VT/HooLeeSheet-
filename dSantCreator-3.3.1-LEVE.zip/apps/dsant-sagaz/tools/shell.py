"""Somente /shell explícito na CLI com --allow-shell. Sem execução via HTTP."""
import os
import platform
import signal
import subprocess
import tempfile
CAP = 12000

def run(cmd, cwd="."):
    timeout = max(1, int(os.environ.get("SAGAZ_SHELL_TIMEOUT", "180")))
    windows = platform.system() == "Windows"
    argv = ["powershell", "-NoProfile", "-Command", cmd] if windows else ["bash", "-lc", cmd]
    env = {k: v for k, v in os.environ.items() if not k.startswith("SAGAZ_API") and k != "SAGAZ_TOKEN"}
    # Saída em disco temporário evita reter saída ilimitada na RAM.
    with tempfile.TemporaryFile() as output:
        try:
            p = subprocess.Popen(argv, cwd=cwd, stdout=output, stderr=subprocess.STDOUT,
                                 env=env, start_new_session=not windows)
            try:
                code = p.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                if windows:
                    subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True)
                else:
                    os.killpg(p.pid, signal.SIGKILL)
                p.wait()
                code = 124
            output.seek(0)
            raw = output.read(CAP + 1)
            text = raw[:CAP].decode("utf-8", errors="replace")
            if code == 124:
                text += f"\ntimeout {timeout}s"
            return {"code": code, "out": text, "trunc": len(raw) > CAP}
        except OSError as exc:
            return {"code": 1, "out": str(exc), "trunc": False}
