import os
from pathlib import Path
import threading
_MODEL = None
_LOCK = threading.Lock()

def _load():
    global _MODEL
    if _MODEL is None:
        from faster_whisper import WhisperModel
        device = os.environ.get("SAGAZ_WHISPER_DEVICE", "auto")
        # CTranslate2 detecta dispositivo; não exige instalar torch.
        _MODEL = WhisperModel(os.environ.get("SAGAZ_WHISPER_MODEL", "large-v3"),
                              device=device, compute_type="int8")
    return _MODEL

def transcribe(audio: Path):
    if not audio or not Path(audio).is_file():
        raise ValueError("arquivo de áudio ausente")
    with _LOCK:
        segments, info = _load().transcribe(str(audio), vad_filter=True, beam_size=5,
                                           vad_parameters={"min_silence_duration_ms": 600})
        return {"lang": info.language, "dur": round(info.duration, 1),
                "segs": [{"t": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()} for s in segments]}

def to_text(result):
    return "\n".join(f"[{int(s['t']//60):02d}:{int(s['t']%60):02d}] {s['text']}" for s in result["segs"])
