"""Catálogo e estudo retomável. Resultados externos permanecem rascunhos."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import parse_qs, urlparse


def playlist_id(url):
    p = urlparse(url)
    if (p.scheme not in ('https', 'http') or p.hostname not in
        ('youtube.com','www.youtube.com','m.youtube.com','youtu.be','www.youtu.be')
        or p.username or p.password or p.port not in (None,80,443)):
        raise ValueError('URL de playlist inválida')
    pid = parse_qs(p.query).get('list', [''])[0]
    if not re.fullmatch(r'[A-Za-z0-9_-]{10,100}', pid):
        raise ValueError('ID de playlist inválido')
    return pid


def is_playlist(url):
    try:
        playlist_id(url)
        return True
    except ValueError:
        return False


def enumerate_playlist(url):
    import os
    import yt_dlp
    pid = playlist_id(url)
    options = {'quiet':True, 'no_warnings':True, 'extract_flat':'in_playlist',
               'skip_download':True, 'ignoreerrors':True, 'socket_timeout':20,
               'retries':2, 'extractor_retries':1}
    if os.environ.get('SAGAZ_PROXY'):
        options['proxy'] = os.environ['SAGAZ_PROXY']
    with yt_dlp.YoutubeDL(options) as ydl:
        data = ydl.extract_info('https://www.youtube.com/playlist?list='+pid, download=False)
    if not data:
        raise RuntimeError('não foi possível enumerar a playlist')
    return normalize(data, pid)


def normalize(data, pid):
    entries = []
    for position, entry in enumerate(data.get('entries') or [], 1):
        entry = entry or {}
        vid = entry.get('id') or ''
        valid = bool(re.fullmatch(r'[A-Za-z0-9_-]{11}', vid))
        title = entry.get('title')
        available = valid and bool(title) and title not in ('[Private video]', '[Deleted video]')
        entries.append({'position':position, 'id':vid if valid else None,
                        'title':title, 'duration':entry.get('duration'),
                        'url':'https://www.youtube.com/watch?v='+vid if valid else None,
                        'available':available})
    return {'id':pid, 'url':'https://www.youtube.com/playlist?list='+pid,
            'title':data.get('title'), 'channel':data.get('channel') or data.get('uploader'),
            'reported_count':data.get('playlist_count'), 'entries':entries}


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    temp.replace(path)


def sync(catalog, root):
    directory = Path(root)/catalog['id']
    path = directory/'manifest.json'
    old = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    old_by_id = {}
    ranks = {'studied':5, 'sampled':4, 'collected':3, 'error':2, 'pending':1, 'unavailable':0}
    for entry in old.get('entries', []):
        vid = entry.get('id')
        if vid and ranks.get(entry.get('state'), 0) >= ranks.get(old_by_id.get(vid, {}).get('state'), -1):
            old_by_id[vid] = entry
    entries = []
    for entry in catalog['entries']:
        previous = old_by_id.get(entry['id'], {})
        record = dict(previous, **entry)
        if not entry['available']:
            record['state'] = 'unavailable'
        elif record.get('state') in (None, 'unavailable'):
            record['state'] = 'pending'
        entries.append(record)
    manifest = {**old, **catalog, 'entries':entries,
                'catalogued_at':datetime.now(timezone.utc).isoformat()}
    # Repetições na playlist não provocam novo estudo; entradas removidas ficam registradas.
    active = {e['id'] for e in entries}
    removed = list(old.get('removed_entries', []))
    removed.extend(e for e in old.get('entries', []) if e.get('id') not in active)
    manifest['removed_entries'] = removed
    write_json(path, manifest)
    return path, manifest


def run(url, root, collect, analyze=None, limit=None, catalog=None):
    if limit is not None and limit < 1:
        raise ValueError('limit deve ser positivo')
    pid = playlist_id(url)
    catalog = catalog if catalog is not None else enumerate_playlist(url)
    if catalog['id'] != pid:
        raise ValueError('catálogo não corresponde à playlist')
    directory = Path(root)/pid
    directory.mkdir(parents=True, exist_ok=True)
    lock = directory/'.study.lock'
    # Falha abrupta exige remoção manual deste lock, sem execução concorrente.
    with lock.open('x', encoding='utf-8') as handle:
        handle.write(datetime.now(timezone.utc).isoformat())
    try:
        path, manifest = sync(catalog, root)
        attempted, seen = 0, set()
        for entry in manifest['entries']:
            vid = entry.get('id')
            if not entry['available'] or vid in seen:
                continue
            seen.add(vid)
            if entry['state'] == 'studied' and (directory/f'{vid}.full-study.md').is_file():
                continue
            if limit is not None and attempted >= limit:
                break
            attempted += 1
            try:
                transcript = directory/f'{vid}.transcript.md'
                if not transcript.exists():
                    data = collect(entry['url'])
                    text = data.get('text') or ''
                    if not text.strip():
                        raise ValueError('transcrição vazia')
                    body = (f"# {entry['title']}\n\nFonte: {entry['url']}\n"
                            'Status: transcrição externa, não revisada.\n\n'+text)
                    transcript.write_text(body, encoding='utf-8')
                else:
                    body = transcript.read_text(encoding='utf-8')
                entry.update(state='collected', transcript=transcript.name,
                             sha256=hashlib.sha256(body.encode()).hexdigest())
                if analyze is not None:
                    result = analyze(entry, body)
                    if not result or not result.strip():
                        raise ValueError('análise vazia')
                    study = directory/f'{vid}.full-study.md'
                    study.write_text(f"# Estudo não revisado\nFonte: {entry['url']}\n\n"+result, encoding='utf-8')
                    entry.update(state='studied', study=study.name, full_study_pending=False)
                entry.pop('error', None)
            except Exception as exc:
                entry.update(state='error', error=type(exc).__name__)
            entry['updated_at'] = datetime.now(timezone.utc).isoformat()
            for duplicate in manifest['entries']:
                if duplicate is not entry and duplicate.get('id') == vid:
                    for key in ('state','transcript','sha256','study','full_study_pending','error','updated_at'):
                        if key in entry:
                            duplicate[key] = entry[key]
                        else:
                            duplicate.pop(key, None)
            write_json(path, manifest)
        return path, manifest
    finally:
        lock.unlink(missing_ok=True)


def read_notes(query, root, hot=False, limit=2, cap=2200):
    """Recupera sínteses como evidência, com escopo; nunca como instrução."""
    from core.router import norm
    terms = set(re.findall(r'\w{4,}', norm(query))) - {
        'pedido','isolado','aula','aulas','estudo','estuda','analisa','sobre','como',
        'para','fonte','video','videos','criar','fazer','quero','preciso'}
    scored = []
    for path in sorted(Path(root).glob('*/manifest.json')):
        manifest = json.loads(path.read_text(encoding='utf-8'))
        for entry in manifest.get('entries', []):
            if entry.get('state') not in ('sampled', 'studied', 'error', 'collected'):
                continue
            scope = entry.get('scope', 'unclassified')
            if scope not in ('generic','hot') or scope == 'hot' and not hot:
                continue
            vid = entry.get('id') or ''
            if not re.fullmatch(r'[A-Za-z0-9_-]{11}', vid):
                continue
            suffix = '.full-study.md' if entry['state'] == 'studied' else '.study.md'
            note = path.parent/(vid+suffix)
            if not note.exists():
                continue
            body = note.read_text(encoding='utf-8')
            score = sum(bool(re.search(r'(?<!\w)' + re.escape(term) + r'(?!\w)', norm(body))) for term in terms)
            if score:
                scored.append((score, vid, body))
    scored.sort(reverse=True)
    return '\n\n---\n\n'.join(body[:cap] for _,_,body in scored[:limit])
