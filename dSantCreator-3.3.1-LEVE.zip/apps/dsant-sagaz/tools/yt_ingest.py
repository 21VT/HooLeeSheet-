import json
import os
from pathlib import Path
import re
import threading
from urllib.parse import parse_qs, urlparse
ROOT = Path(__file__).resolve().parent.parent
_LOCK = threading.Lock()
_LOCKS = {}

def cache_dir():
    return Path(os.environ.get("SAGAZ_CACHE_DIR", str(ROOT / "cache")))

def video_id(url):
    parsed = urlparse(url)
    if parsed.scheme not in ("https", "http") or parsed.username or parsed.password or parsed.port not in (None, 80, 443):
        raise ValueError("URL YouTube inválida")
    host = (parsed.hostname or "").lower()
    if host not in ("youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "www.youtu.be"):
        raise ValueError("somente URLs do YouTube são aceitas")
    parts = parsed.path.strip("/").split("/")
    if host.endswith("youtu.be"):
        vid = parts[0]
    elif parsed.path == "/watch":
        vid = parse_qs(parsed.query).get("v", [""])[0]
    elif len(parts) == 2 and parts[0] in ("shorts", "live", "embed"):
        vid = parts[1]
    else:
        vid = ""
    if not re.fullmatch(r"[A-Za-z0-9_-]{11}", vid):
        raise ValueError("URL sem ID de vídeo válido")
    return vid

def directory(vid):
    if not re.fullmatch(r"[A-Za-z0-9_-]{11}", vid):
        raise ValueError("ID inválido")
    return cache_dir() / vid

def audio_path(vid):
    return next((f for f in directory(vid).glob("audio.*") if f.suffix in (".m4a", ".webm", ".mp3", ".opus", ".wav", ".mp4")), None)

def video_path(vid):
    return next((f for f in directory(vid).glob("video.*") if f.suffix in (".mp4", ".webm", ".mkv")), None)

def cache_hit(vid):
    return (directory(vid) / "meta.json").exists() and audio_path(vid) is not None and video_path(vid) is not None

def _subs(d):
    for path in sorted(d.glob("*.json3")):
        try:
            events = json.loads(path.read_text(encoding="utf-8")).get("events", [])
            lines = []
            for event in events:
                text = "".join(s.get("utf8", "") for s in event.get("segs", [])).strip()
                if text:
                    seconds = event.get("tStartMs", 0) / 1000
                    lines.append(f"[{int(seconds//60):02d}:{int(seconds%60):02d}] {text}")
            if lines:
                return "\n".join(lines)
        except (ValueError, OSError):
            continue
    return ""

def ingest(url):
    vid = video_id(url)
    with _LOCK:
        lock = _LOCKS.setdefault(vid, threading.Lock())
    with lock:
        d = directory(vid)
        d.mkdir(parents=True, exist_ok=True)
        if cache_hit(vid):
            try:
                meta = json.loads((d / "meta.json").read_text(encoding="utf-8"))
                meta.update(cached=True, transcript=_subs(d))
                return meta
            except ValueError:
                pass
        import yt_dlp
        common = {"quiet": True, "no_warnings": True, "noprogress": True,
                  "noplaylist": True, "retries": 2, "fragment_retries": 2,
                  "socket_timeout": 25, "max_filesize": 300_000_000,
                  "match_filter": lambda info, **kw: "vídeo acima de 2 horas" if (info.get("duration") or 0) > 7200 else None}
        if os.environ.get("SAGAZ_PROXY"):
            common["proxy"] = os.environ["SAGAZ_PROXY"]
        canonical = f"https://www.youtube.com/watch?v={vid}"
        warnings = []
        opts = dict(common, format="bestaudio/best", outtmpl=str(d / "audio.%(ext)s"),
                    writesubtitles=True, writeautomaticsub=True,
                    subtitleslangs=["pt", "pt-BR", "en"], subtitlesformat="json3")
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(canonical, download=True)
        except Exception:
            # Falha de legenda não impede tentar áudio e metadados novamente.
            opts.update(writesubtitles=False, writeautomaticsub=False)
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(canonical, download=True)
            warnings.append("legendas indisponíveis; usar transcrição local")
        if not info or not audio_path(vid):
            raise RuntimeError("áudio não baixado; confira disponibilidade, duração e limite de tamanho")
        try:
            with yt_dlp.YoutubeDL(dict(common, format="best[height<=480]/bestvideo[height<=480]", outtmpl=str(d / "video.%(ext)s"))) as ydl:
                ydl.extract_info(canonical, download=True)
            if not video_path(vid):
                warnings.append("vídeo visual não baixado")
        except Exception:
            warnings.append("download visual falhou; análise limitada ao áudio/texto")
        meta = {"id": vid, "title": info.get("title", ""), "channel": info.get("uploader", ""),
                "duration": info.get("duration", 0), "views": info.get("view_count", 0),
                "upload": info.get("upload_date", ""), "desc": (info.get("description") or "")[:4000],
                "url": canonical, "cached": False, "transcript": _subs(d), "warnings": warnings}
        tmp = d / "meta.tmp"
        tmp.write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
        tmp.replace(d / "meta.json")
        return meta
