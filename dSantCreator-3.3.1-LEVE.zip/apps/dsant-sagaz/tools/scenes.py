import os
from pathlib import Path
import re
import subprocess
from shutil import which
from .yt_ingest import directory, video_path

def detect(vid, audio=None):
    src = video_path(vid)
    if not which("ffmpeg") or not src:
        return []
    threshold = float(os.environ.get("SAGAZ_SCENE_THRESHOLD", ".3"))
    if not 0 < threshold < 1:
        raise ValueError("SAGAZ_SCENE_THRESHOLD precisa estar entre 0 e 1")
    result = subprocess.run(["ffmpeg", "-nostdin", "-hide_banner", "-i", str(src), "-an", "-vf",
                             f"select=gt(scene\\,{threshold}),showinfo", "-f", "null", "-"],
                            capture_output=True, text=True, timeout=600)
    if result.returncode:
        raise RuntimeError("ffmpeg falhou na detecção de cenas")
    times = [float(t) for t in re.findall(r"pts_time:([0-9.]+)", result.stderr)]
    (directory(vid) / "scenes.txt").write_text("\n".join(map(str, times)), encoding="utf-8")
    return times

def sheet(vid, times, n=12):
    src = video_path(vid)
    if not which("ffmpeg") or not src:
        return None
    d = directory(vid)
    # Inclui frame inicial mesmo quando não há cortes.
    selected = list(dict.fromkeys([0.0] + list(times)))[:n]
    frames = []
    for i, t in enumerate(selected):
        frame = d / f"f{i:02d}.jpg"
        result = subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-ss", str(t), "-i", str(src),
                                 "-frames:v", "1", "-vf", "scale=320:180:force_original_aspect_ratio=decrease,pad=320:180:(ow-iw)/2:(oh-ih)/2", "-y", str(frame)],
                                capture_output=True, timeout=60)
        if result.returncode == 0 and frame.exists():
            frames.append(frame)
    if not frames:
        return None
    # Cada entrada tem tamanho fixo; layout suporta qualquer quantidade de 1 a 12.
    out = d / "sheet.jpg"
    if len(frames) == 1:
        out.write_bytes(frames[0].read_bytes())
        return str(out)
    args = ["ffmpeg", "-nostdin", "-v", "error", "-y"]
    for frame in frames:
        args += ["-i", str(frame)]
    layout = "|".join(f"{i%4*320}_{i//4*180}" for i in range(len(frames)))
    graph = "".join(f"[{i}:v]" for i in range(len(frames))) + f"xstack=inputs={len(frames)}:layout={layout}:fill=black[o]"
    result = subprocess.run(args + ["-filter_complex_threads", "1", "-filter_complex", graph, "-map", "[o]", "-frames:v", "1", str(out)],
                            capture_output=True, timeout=60)
    if result.returncode:
        raise RuntimeError("ffmpeg falhou na contact sheet")
    return str(out)
