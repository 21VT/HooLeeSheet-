# Materiais — edição leve

O código, os templates das skills e os estudos continuam incluídos. Para reduzir o tamanho, esta edição não contém os 15 vídeos, documentos e pacotes de origem de materials/originals/.

Esses arquivos não são dependências do núcleo. O catálogo SOURCES.json conserva os hashes e a atribuição. Seus caminhos históricos identificam os arquivos no pacote completo, não arquivos instalados nesta edição.

Pacote completo: https://chatgpt.com/library?file_id=libfile_dad020897948819194d1a746ad6c2be2&account_id=personal
