# Source catalog

This lightweight edition retains provenance in SOURCES.json. Original media and source archives are available only in the full package linked in README.md.
